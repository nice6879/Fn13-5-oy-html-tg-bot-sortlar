def x(x):
    y = 'aeiouAEIOU'
    y = [i for i in x if i in y]
    Z = ''.join(y[::-1])
    javob = ''
    soni = 0
    for i in x:
        if i in y:
            javob += Z[soni]
            soni+=1
        else:
            javob += i
    return javob
print(x("salom"))